(function($) {

  $('#batch_no').parent().append('<ul class="list-item" id="newbatch" name="batch_no"></ul>');
  $('#batch_no option').each(function(){
      $('#newbatch').append('<li value="' + $(this).val() + '">'+$(this).text()+'</li>');
  });
  $('#batch_no').remove();
  $('#newbatch').attr('id', 'batch_no');
  $('#batch_no li').first().addClass('init');
  $("#batch_no").on("click", ".init", function() {
      $(this).closest("#batch_no").children('li:not(.init)').toggle();
  });

  $('input[type=radio').on("change", function(){
     const labelText = $(this).next("label").text();
     $("input[name=payment]").val(labelText);
  });

  var allOptions = $("#batch_no").children('li:not(.init)');
  $("#batch_no").on("click", "li:not(.init)", function() {
    // console.log("teste");
      allOptions.removeClass('selected');
      $(this).addClass('selected');
      $("#batch_no").children('.init').html($(this).html());
      $("#batch_no").children('.init').val($(this).val());
      $("#batch").val($(this).val());
      allOptions.toggle();
  });

  var marginSlider = document.getElementById('slider-margin');
  if (marginSlider != undefined) {
      noUiSlider.create(marginSlider, {
            start: [500],
            step: 10,
            connect: [true, false],
            tooltips: [true],
            range: {
                'min': 0,
                'max': 1000
            },
            format: wNumb({
                decimals: 0,
                thousand: ',',
                prefix: '$ ',
            })
    });
  }
  $('#reset').on('click', function(){
      $('#register-form').reset();
  });

  $('#register-form').validate({
    rules : {
        first_name : {
            required: true,
        },
        last_name : {
            required: true,
        },
        company : {
            required: true
        },
        email : {
            required: true,
        },
        contact : {
            required: true,
        },
        nid : {
            required: true,
        },
        dob : {
            required: true,
        },
        batch_no : {
            required: true,
        },
        payment : {
            required: true,
        },
        password : {
            required: true,
        },
        password_confirmation : {
            required: true,
        },
    },
    onfocusout: function(element) {
        $(element).valid();
    },
});

    jQuery.extend(jQuery.validator.messages, {
        required: "",
        remote: "",
        email: "",
        url: "",
        date: "",
        dateISO: "",
        number: "",
        digits: "",
        creditcard: "",
        equalTo: ""
    });
})(jQuery);
