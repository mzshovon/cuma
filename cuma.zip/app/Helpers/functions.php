<?php

use Illuminate\Pagination\LengthAwarePaginator;
use Illuminate\Pagination\Paginator;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Mail;

if (!function_exists('customPaginate')) {
    /**
     * @param mixed $items
     * @param int $perPage
     * @param null $page
     *
     * @return mixed
     */
    function customPaginate($items, $perPage = 5, $page = null)
    {
        $page = $page ?: (Paginator::resolveCurrentPage() ?: 1);
        $items = $items instanceof Collection ? $items : Collection::make($items);
        return new LengthAwarePaginator($items->forPage($page, $perPage), $items->count(), $perPage, $page, [
            'path' => Paginator::resolveCurrentPath()
        ]);
    }
}

if (!function_exists('getUserInfo')) {
    /**
     * @return mixed
     */
    function getUserInfo()
    {
        return auth()->user();
    }
}

if (!function_exists('storeOrUpdateImage')) {
    /**
     * @return mixed
     */
    function storeOrUpdateImage($filePath, $file, $fileNamePrefix, $unlinkExisting = true)
    {
        if(!File::exists($filePath)) {
            mkdir($filePath, 0777, true);
        }
        $fileName = "$fileNamePrefix.".$file->getClientOriginalExtension();
        $dirPath = $filePath . $fileName;
        if($unlinkExisting) {
            if (File::exists($dirPath)) {
                File::deleteDirectory($dirPath);
            }
        }
        file_put_contents($dirPath, file_get_contents($file));
        return $dirPath;
    }
}

if (!function_exists('sendMailWithTemplate')) {
    /**
     * @return mixed
     */
    function sendMailWithTemplate($data, $template, $to, $cc = null)
    {
        $subject = $data['subject'];
        if(array_key_exists("message", $data)) {
            $message = $data["message"];
            unset($data['message']);
            $data['mailMessage'] = $message;
        }
        Mail::send($template, $data, function ($mail) use ($subject, $to, $cc) {
            $mail->to($to);
            if($cc){
                $mail->cc($cc);
            }
            $mail->subject($subject);
        });
        return true;
    }
}

